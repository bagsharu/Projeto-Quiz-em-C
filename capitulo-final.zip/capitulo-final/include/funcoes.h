#ifndef FUNCOES_H
#define FUNCOES_H
#include "../include/modulo.h"


#define PERGUNTA 5
#define TAM 100

void exibirMenu();
int cadastrarPergunta(Pergunta perguntas[PERGUNTA], int indice);
void listarPerguntas(Pergunta perguntas[PERGUNTA], int totalPerguntas);
void exibirEstatisticas(Jogador jogadores[TAM], int totalJogadores);
void jogar(Pergunta perguntas[PERGUNTA],Jogador jogadores[TAM], int totalPerguntas, int *totalAcertos, int *totalRespostas, int *totalJogadores);

#endif