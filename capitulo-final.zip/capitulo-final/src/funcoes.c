#include "../include/funcoes.h"
#include "../include/modulo.h"
#include <stdio.h>
#include <string.h>

void exibirMenu(){

    printf("=== Quiz ===\n"
        "1. Jogar\n"
        "2. Cadastrar pergunta\n"
        "3. Listar perguntas\n"
        "4. Ranking dos Jogadores\n"
        "0. Sair\n"
        "Digite uma opcao:\n");
}

int cadastrarPergunta(Pergunta perguntas[PERGUNTA], int indice) {
    printf("Digite a pergunta numero %d:\n", indice + 1);
    fgets(perguntas[indice].enunciado, TAM, stdin);
    perguntas[indice].enunciado[strcspn(perguntas[indice].enunciado, "\n")] = '\0';

    printf("Insira a alternativa A:\n");
    fgets(perguntas[indice].alternativas[0], TAM, stdin);
    perguntas[indice].alternativas[0][strcspn(perguntas[indice].alternativas[0], "\n")] = '\0';

    printf("Insira a alternativa B:\n");
    fgets(perguntas[indice].alternativas[1], TAM, stdin);
    perguntas[indice].alternativas[1][strcspn(perguntas[indice].alternativas[1], "\n")] = '\0';

    printf("Insira a alternativa C:\n");
    fgets(perguntas[indice].alternativas[2], TAM, stdin);
    perguntas[indice].alternativas[2][strcspn(perguntas[indice].alternativas[2], "\n")] = '\0';

    printf("Insira a alternativa D:\n");
    fgets(perguntas[indice].alternativas[3], TAM, stdin);
    perguntas[indice].alternativas[3][strcspn(perguntas[indice].alternativas[3], "\n")] = '\0';

    printf("Agora, qual delas e a correta?\n");
    scanf(" %c", &perguntas[indice].respostaCorreta);
    while (getchar() != '\n');

    return 1;
}

void listarPerguntas(Pergunta perguntas[PERGUNTA], int totalPerguntas)
{
    if (totalPerguntas == 0) {
        printf("Nenhuma pergunta cadastrada!\n");
        return;
    }

    printf("\n=== Perguntas cadastradas ===\n");

    for (int i = 0; i < totalPerguntas; i++) {
        printf("%d. %s\n", i + 1, perguntas[i].enunciado);
    }
}

void exibirEstatisticas(Jogador jogadores[TAM], int totalJogadores){
    
    Jogador ranking[TAM];

    if(totalJogadores == 0){

        printf("Nenhum registro de jogadores encontrado.\n");
        return;
    }

    for (int i = 0; i < totalJogadores; i++){

        ranking[i] = jogadores[i];
    }

    bubbleSort(ranking, totalJogadores);

    printf("\n=== Ranking ===\n");

        for (int i = 0; i < totalJogadores; i++) {
        printf("%d. %s - %.2f%% (%d/%d)\n",
            i + 1,
            ranking[i].nome,
            ranking[i].percentual,
            ranking[i].acertos,
            ranking[i].totalPerguntas
        );
    }
}

void jogar(Pergunta perguntas[PERGUNTA], Jogador jogadores[TAM], int totalPerguntas, int *totalAcertos, int *totalRespostas, int *totalJogadores) {
    char resposta;
    int pontos = 0;

    printf("Digite o seu nome, jogador(a): ");
    fgets(jogadores[*totalJogadores].nome, TAM, stdin);

    jogadores[*totalJogadores].nome[strcspn(jogadores[*totalJogadores].nome, "\n")] = '\0';

    if (totalPerguntas == 0) {
        printf("Nenhuma pergunta cadastrada!\n");
        return;
    }

    printf("\n=== Iniciando Quiz ===\n");

    for (int i = 0; i < totalPerguntas; i++) {
        printf("\nPergunta %d:\n", i + 1);
        printf("%s\n", perguntas[i].enunciado);

        printf("A) %s\n", perguntas[i].alternativas[0]);
        printf("B) %s\n", perguntas[i].alternativas[1]);
        printf("C) %s\n", perguntas[i].alternativas[2]);
        printf("D) %s\n", perguntas[i].alternativas[3]);

        do {
            printf("Sua resposta (A - D): \n");
            scanf(" %c", &resposta);
            while (getchar() != '\n');

            if (resposta < 'A' || resposta > 'D') {
                printf("Resposta invalida!\n");
            }

        } while (resposta < 'A' || resposta > 'D');

        (*totalRespostas)++;

        if (resposta == perguntas[i].respostaCorreta) {
            printf("Resposta correta!\n");
            pontos++;
            (*totalAcertos)++;
        } else {
            printf("Resposta incorreta!\n");
        }
    }

    printf("\n=== Resultado ===\n");
    jogadores[*totalJogadores].acertos = pontos;
    jogadores[*totalJogadores].percentual = (pontos * 100.0) / (totalPerguntas);
    jogadores[*totalJogadores].totalPerguntas = totalPerguntas;
    printf("Jogador(a): %s\n", jogadores[*totalJogadores].nome);
    printf("Acertos: %d de %d\n", jogadores[*totalJogadores].acertos, totalPerguntas);
    printf("Percentual: %.2f%%\n", jogadores[*totalJogadores].percentual);

    (*totalJogadores)++;
}